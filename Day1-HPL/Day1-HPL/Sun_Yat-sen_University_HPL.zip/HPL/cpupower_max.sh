pssh -l root -h /public/home/asc17/peterrich/all_nodes cpupower frequency-set --max $1
