pssh -l root -h nodes.gpu nvidia-smi -pl $1
